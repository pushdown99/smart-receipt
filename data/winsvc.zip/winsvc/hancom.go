package main

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/fatih/color"
	"github.com/jacobsa/go-serial/serial"
	"github.com/joho/godotenv"
	"github.com/kardianos/service"
	"github.com/matishsiao/goInfo"
)

////////////////////////////////////////////////////////

type GoWindowsService struct{}

func (goWindowsService *GoWindowsService) Start(windowsService service.Service) error {
	color.Set(color.FgHiWhite)
	osArch = runtime.GOOS + "/" + runtime.GOARCH
	log.Println("#")
	log.Printf("# POS Agent Started! (%s)", osArch)
	log.Println("#")
	color.Set(color.FgWhite)

	log.Println("")
	gi := goInfo.GetInfo()
	log.Println("[v]", gi)
	//b, _ := json.Marshal(gi)
	//SysInfo = string(b[:])
	osInfo = string(gi.Kernel + "/" + gi.Core)
	log.Println("")

	if _, err := os.Stat("C:\\Program Files (x86)"); !os.IsNotExist(err) {
		osInfo += " (64bit)"
	} else {
		osInfo += " (32bit)"
	}

	//out, err := exec.Command("cmd", "reg query 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion' /v BuildLabEx").Output()
	//if err != nil {
	//	log.Fatal(err)
	//} else {
	//	log.Println("out", string(out[:]))
	//}

	go goWindowsService.run()
	return nil
}

func (goWindowsService *GoWindowsService) run() {
	hcConfig()

	wg := sync.WaitGroup{}

	if strings.ToUpper(posType) == "BNK" {
		wg.Add(5)
		go Extract()

		hcHeartBeat()
		hcCheckIn()

		wg.Wait()
	} else if strings.ToUpper(posType) == "COM" {
		in := hcOpenCOM(Port1)
		if in == nil {
			return
		}
		out := hcOpenCOM(Printer)
		if out == nil {
			return
		}

		wg.Add(5)
		go RunCOM(in, out, Port1, Printer)
		go RunCOM(out, in, Printer, Port1)

		hcHeartBeat()
		hcCheckIn()

		wg.Wait()
	} else {
		in, err := os.OpenFile(Port1, os.O_RDWR, 0666)
		if err != nil {
			return
		}
		out, err := os.OpenFile(Printer, os.O_RDWR, 0666)
		if err != nil {
			return
		}
		wg.Add(5)
		go RunLPT(in, out, Port1, Printer)
		go RunLPT(out, in, Printer, Port1)

		hcHeartBeat()
		hcCheckIn()
	}
}

func (goWindowsService *GoWindowsService) Stop(windowsService service.Service) error {
	color.Set(color.FgHiWhite)
	log.Println("#")
	log.Println("# POS Agent Stopped!")
	log.Println("#")
	color.Set(color.FgWhite)

	return nil
}

func main() {
	LOG_FILE := "c:\\hc\\hancom.log"
	fp, err := os.OpenFile(LOG_FILE, os.O_APPEND|os.O_RDWR|os.O_CREATE, 0644)
	if err != nil {
		log.Panic(err)
	}
	defer fp.Close()
	//multiWriter := io.MultiWriter(&hcWriter{Writer: fp}, os.Stdout)
	multiWriter := io.MultiWriter(fp, os.Stdout)
	log.SetOutput(multiWriter)
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	serviceConfig := &service.Config{
		Name:        "GoWindowsService",
		DisplayName: "Go Windows service",
		Description: "Go Windows service",
	}

	goWindowsService := &GoWindowsService{}
	windowsService, err := service.New(goWindowsService, serviceConfig)
	if err != nil {
		log.Println(err)
	}

	err = windowsService.Run()
	if err != nil {
		log.Println(err)
	}
}

////////////////////////////////////////////////////////

type JsonPost struct {
	Data      string
	Timestamp int64
}

func Extract() {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Extract files (%s%s_*)", bnkRepo, bnkPrefix)
	color.Set(color.FgWhite)
	if _, err := os.Stat(bnkRepo); os.IsNotExist(err) {
		color.Set(color.FgRed)
		log.Printf("[x] Repositories is not exist (%s)", bnkRepo)
		color.Set(color.FgWhite)
		return
	}

	latest := time.Now()
	for {
		files, err := ioutil.ReadDir(bnkRepo)
		if err != nil {
			fmt.Println(err)
		}
		for _, f := range files {
			idx := strings.Index(f.Name(), bnkPrefix)
			if idx == 0 {
				log.Printf("[-] File (%s %s)", f.Name(), f.ModTime())
				if f.ModTime().Sub(latest) >= 0 {
					fmt.Println(f.Name(), f.ModTime(), f.ModTime().Sub(latest))
					buf, _ := ioutil.ReadFile(bnkRepo + f.Name())
					hcPostReceipt(buf)
				}
			}
		}
		latest = time.Now()         // update
		time.Sleep(5 * time.Second) // 1 sec => 5 sec
	}
}

func hcPostReceipt(buf []byte) {
	b, _ := json.Marshal(JsonPost{Data: hex.EncodeToString(buf), Timestamp: time.Now().Unix()})
	resp, err := http.Post(httpHost+"/receipt/probe/"+uidNum, "application/json", bytes.NewBuffer(b))
	//defer resp.Body.Close()

	log.Printf("[p] http post %s/receipt/probe/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http post error: ", err)
		color.Set(color.FgWhite)
	} else {
		log.Printf("[-] Http response: %d", resp.StatusCode)
	}
}

func RunCOM(in io.ReadWriteCloser, out io.ReadWriteCloser, port1 string, port2 string) {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Run (%s => %s)", port1, port2)
	color.Set(color.FgWhite)
	for {
		buf := make([]byte, 32768)
		n, err := in.Read(buf)

		if err != nil {
			if err != io.EOF {
				color.Set(color.FgRed)
				log.Printf("[x] Reading from serial port: ", err)
				color.Set(color.FgWhite)
			}
		} else {
			buf = buf[:n]
			if n > 0 {
				log.Printf("[-] read %s  %d bytes, %s", port1, n, hex.EncodeToString(buf))
				nb, _ := out.Write(buf)
				log.Printf("[-] write %s %d bytes %s", port2, nb, hex.EncodeToString(buf))
				hcPostReceipt(buf)
			}
		}
		buf = nil
	}
}

func RunLPT(in *os.File, out *os.File, port1 string, port2 string) {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Run (%s => %s)", port1, port2)
	color.Set(color.FgWhite)
	for {
		buf := make([]byte, 32768)
		n, err := in.Read(buf)

		if err != nil {
			if err != io.EOF {
				color.Set(color.FgRed)
				log.Printf("[x] Reading from serial port: ", err)
				color.Set(color.FgWhite)
			}
		} else {
			buf = buf[:n]
			if n > 0 {
				log.Printf("[-] read %s  %d bytes, %s", port1, n, hex.EncodeToString(buf))
				nb, _ := out.Write(buf)
				log.Printf("[-] write %s %d bytes %s", port2, nb, hex.EncodeToString(buf))
				hcPostReceipt(buf)
			}
		}
		buf = nil
	}
}

////////////////////////////////////////////////////////

func hcConfig() {
	ipAddr = GetOutboundIP().String()
	macAddr = GetOutboundMac(ipAddr)
	log.Println("----------------------------------------------------------------")
	if getConfig() == false {
		color.Set(color.FgRed)
		log.Printf("[x] Please, check your POS configuration.")
		color.Set(color.FgWhite)
		return
	}
	log.Println("----------------------------------------------------------------")
}

func hcOpenCOM(device string) io.ReadWriteCloser {

	baudrate, _ := strconv.Atoi(baudRate)
	intchtmo, _ := strconv.Atoi(intChTimeout)
	minreadsize, _ := strconv.Atoi(minReadSize)

	options := serial.OpenOptions{
		PortName: device,
		BaudRate: uint(baudrate),
		DataBits: 8,
		StopBits: 1,
		// ParityMode:
		// RTSCTSFlowControl:
		InterCharacterTimeout: uint(intchtmo),    //msec
		MinimumReadSize:       uint(minreadsize), //4
		// InterCharacterTimeout > 0 and MinimumReadSize > 0
		//     Calls to Read() return when at least MinimumReadSize bytes are
		//     available or when InterCharacterTimeout milliseconds elapse between
		//     received bytes. The inter-character timer is not started until the
		//     first byte arrives.
		//
		// InterCharacterTimeout = 0 and MinimumReadSize > 0
		//     Calls to Read() return only when at least MinimumReadSize bytes are
		//     available. The inter-character timer is not used.
		//
		// For windows usage, these options (termios) do not conform well to the
		//     windows serial port / comms abstractions.  Please see the code in
		//       open_windows setCommTimeouts function for full documentation.
		//       Summary:
		//         Setting MinimumReadSize > 0 will cause the serialPort to block until
		//         until data is available on the port.
		//         Setting IntercharacterTimeout > 0 and MinimumReadSize == 0 will cause
		//         the port to either wait until IntercharacterTimeout wait time is
		//         exceeded OR there is character data to return from the port.
	}
	port, err := serial.Open(options)
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] %s serial.Open: %v", device, err)
		color.Set(color.FgWhite)
		return nil
	}
	return port
}

type JsonCheckIn struct {
	Name string
	Uid  string
	Rcn  string
	Mac  string
	Arch string
	Info string
}

func hcCheckIn() {
	b, _ := json.Marshal(JsonCheckIn{Name: deptName, Uid: uidNum, Rcn: rcnNum, Mac: macAddr, Arch: osArch, Info: osInfo})
	resp, err := http.Post(httpHost+"/check-in", "application/json", bytes.NewBuffer(b))

	log.Printf("[p] http post %s/check-in %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http check-on post error: ", err)
		color.Set(color.FgWhite)
	} else {
		log.Printf("[-] Http response: %d", resp.StatusCode)
	}
}

func doHeartBeat(t time.Time) {
	b, _ := json.Marshal(JsonCheckIn{Name: deptName, Uid: uidNum, Rcn: rcnNum, Mac: macAddr, Arch: osArch, Info: osInfo})
	resp, err := http.Post(httpHost+"/heartbeat/", "application/json", bytes.NewBuffer(b))
	//defer resp.Body.Close()

	log.Printf("[p] http post %s/heartbeat/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http heartbeat post error: ", err)
		color.Set(color.FgWhite)
	} else {

		log.Printf("[-] Http response: %d", resp.StatusCode)
	}

}

func hcHeartBeat() {
	hbtimer, _ := strconv.ParseInt(heartBeat, 10, 32)

	log.Printf("[v] module hcHeartBeat (per %d seconds)", hbtimer)
	go func() {
		ticker := time.NewTicker(time.Duration(hbtimer) * time.Second)
		defer ticker.Stop()

		//doHeartBeat(time.Now())
		for {
			select {
			case t := <-ticker.C:
				doHeartBeat(t)
			}
		}
	}()
}

type hcWriter struct {
	io.Writer
}

func (m *hcWriter) Write(p []byte) (n int, err error) {
	n, err = m.Writer.Write(p)

	if flusher, ok := m.Writer.(interface{ Flush() }); ok {
		flusher.Flush()
	} else if syncer := m.Writer.(interface{ Sync() error }); ok {
		// Preserve original error
		if err2 := syncer.Sync(); err2 != nil && err == nil {
			err = err2
		}
	}
	return
}

////////////////////////////////////////////////////////

func GetOutboundIP() net.IP {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] net.Dial error: %s", err)
		color.Set(color.FgWhite)
	}
	defer conn.Close()
	return conn.LocalAddr().(*net.UDPAddr).IP
}

func GetOutboundMac(currentIP string) string {
	var currentNetworkHardwareName string
	interfaces, _ := net.Interfaces()
	for _, interf := range interfaces {
		if addrs, err := interf.Addrs(); err == nil {
			for _, addr := range addrs {
				if strings.Contains(addr.String(), currentIP) {
					currentNetworkHardwareName = interf.Name
				}
			}
		}
	}
	netInterface, err := net.InterfaceByName(currentNetworkHardwareName)
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Interface error: %s", err)
		color.Set(color.FgWhite)
	}
	return netInterface.HardwareAddr.String()
}

var httpHost string
var deptName string
var uidNum string
var rcnNum string
var macAddr string
var ipAddr string
var baudRate string
var Printer string
var Port1 string
var Port2 string
var Token string
var heartBeat string
var intChTimeout string
var minReadSize string
var posType string
var bnkRepo string
var bnkPrefix string
var osArch string
var osInfo string

func getConfig() bool {
	err := godotenv.Load("c:\\hc\\.env")
	if err != nil {
		log.Printf("Error loading .env file")
		return false
	}
	httpHost = "https://smart.hancomlifecare.com"
	//httpHost = os.Getenv("SERVER")
	deptName = os.Getenv("NAME")
	uidNum = os.Getenv("UID")
	rcnNum = os.Getenv("RCN")
	baudRate = os.Getenv("BAUDRATE")
	Printer = os.Getenv("PRINTER")
	Port1 = os.Getenv("PORT1")
	Port2 = os.Getenv("PORT2")
	heartBeat = os.Getenv("HEARTBEAT")
	intChTimeout = os.Getenv("INTERCHTMO")
	minReadSize = os.Getenv("MINREADSIZE")
	posType = os.Getenv("POSTYPE")
	bnkRepo = os.Getenv("BNK_REPO")
	bnkPrefix = os.Getenv("BNK_PREFIX")
	ipAddr = GetOutboundIP().String()
	macAddr = GetOutboundMac(ipAddr)

	log.Printf("[*] Host                     : %s", httpHost)
	log.Printf("[*] Name                     : %s", deptName)
	log.Printf("[*] Uid                      : %s", uidNum)
	log.Printf("[*] Rcn                      : %s", rcnNum)
	log.Printf("[*] BaudRate                 : %s", baudRate)
	log.Printf("[*] Printer                  : %s", Printer)
	log.Printf("[*] Port1                    : %s", Port1)
	log.Printf("[*] Port2 (POS)              : %s", Port2)
	log.Printf("[*] HeartBeat                : %s", heartBeat)
	log.Printf("[*] Inter Character Timeout  : %s", intChTimeout)
	log.Printf("[*] Minimum Read Size        : %s", minReadSize)
	log.Printf("[*] POS Type                 : %s", posType)
	if strings.ToUpper(posType) == "BNK" {
		log.Printf("[*] BNK Repo                 : %s", bnkRepo)
		log.Printf("[*] BNK Prefix               : %s", bnkPrefix)
	}
	log.Printf("[*] IP address               : %s", ipAddr)
	log.Printf("[*] Mac address              : %s", macAddr)
	if strings.ToUpper(posType) != "BNK" {
		log.Println("----------------------------------------------------------------")
		log.Printf("[v] POS: vPort %s (thuru %s) <=> Printer (%s)", Port2, Port1, Printer)
	}

	return true
}
