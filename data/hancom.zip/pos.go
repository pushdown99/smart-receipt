package main

import (
	"encoding/hex"
	"fmt"
	"os"
	"strings"
)

func main() {
	argc := len(os.Args)
	argv := os.Args[0:]

	if argc < 3 {
		fmt.Printf("")
		fmt.Printf("Usage: %s {port} {data}", argv[0])
		fmt.Printf("")
		return
	}

	f, err := os.OpenFile(strings.ToUpper(argv[1]), os.O_RDWR, 0666)
	if err != nil {
		fmt.Println(err)
		return
	}
	dat, _ := hex.DecodeString(argv[2])
	f.Write(dat)
	f.Close()
}
