package main

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/fatih/color"
	"github.com/gorilla/websocket"
	"github.com/jacobsa/go-serial/serial"
	"github.com/joho/godotenv"
	"github.com/kardianos/service"
	"github.com/matishsiao/goInfo"
	"github.com/webview/webview"
)

////////////////////////////////////////////////////////

type GoWindowsService struct{}

func (goWindowsService *GoWindowsService) Start(windowsService service.Service) error {
	color.Set(color.FgHiWhite)
	osArch = runtime.GOOS + "/" + runtime.GOARCH
	log.Println("#")
	log.Printf("# POS Agent Started! (%s)", osArch)
	log.Println("#")
	color.Set(color.FgWhite)

	log.Println("")
	gi := goInfo.GetInfo()
	log.Println("[v]", gi)
	osInfo = string(gi.Kernel + "/" + gi.Core)
	log.Println("")

	if _, err := os.Stat("C:\\Program Files (x86)"); !os.IsNotExist(err) {
		osInfo += " (64bit)"
	} else {
		osInfo += " (32bit)"
	}
	go goWindowsService.run()
	return nil
}

func (goWindowsService *GoWindowsService) run() {
	hcConfig()

	wg := sync.WaitGroup{}

	if strings.ToUpper(posType) == "BNK" {
		wg.Add(5)
		go Extract()

		if wsHost == "" {
			hcCheckIn()
			hcHeartBeat()
		} else {
			hcSignIn()
			hcWS()
			hcPosHeartBeat()
		}

		wg.Wait()
	} else if strings.ToUpper(posType) == "COM" {
		in := hcOpenCOM(Port1)
		if in == nil {
			return
		}
		out := hcOpenCOM(Printer)
		if out == nil {
			return
		}

		wg.Add(5)
		go RunCOM(in, out, Port1, Printer)
		go RunCOM(out, in, Printer, Port1)

		if wsHost == "" {
			hcCheckIn()
			hcHeartBeat()
		} else {
			hcSignIn()
			hcWS()
			hcPosHeartBeat()
		}

		wg.Wait()
	} else {
		in, err := os.OpenFile(Port1, os.O_RDWR, 0666)
		if err != nil {
			return
		}
		out, err := os.OpenFile(Printer, os.O_RDWR, 0666)
		if err != nil {
			return
		}
		wg.Add(5)
		go RunLPT(in, out, Port1, Printer)
		go RunLPT(out, in, Printer, Port1)

		hcHeartBeat()
		hcCheckIn()
	}
}

func (goWindowsService *GoWindowsService) Stop(windowsService service.Service) error {
	color.Set(color.FgHiWhite)
	log.Println("#")
	log.Println("# POS Agent Stopped!")
	log.Println("#")
	color.Set(color.FgWhite)

	return nil
}

func main() {
	LOG_FILE := "c:\\hc\\hancom.log"
	fp, err := os.OpenFile(LOG_FILE, os.O_APPEND|os.O_RDWR|os.O_CREATE, 0644)
	if err != nil {
		log.Panic(err)
	}
	defer fp.Close()
	multiWriter := io.MultiWriter(fp, os.Stdout)
	log.SetOutput(multiWriter)
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	serviceConfig := &service.Config{
		Name:        "GoWindowsService",
		DisplayName: "Go Windows service",
		Description: "Go Windows service",
	}

	goWindowsService := &GoWindowsService{}
	windowsService, err := service.New(goWindowsService, serviceConfig)
	if err != nil {
		log.Println(err)
	}

	err = windowsService.Run()
	if err != nil {
		log.Println(err)
	}
}

////////////////////////////////////////////////////////

type JsonPost struct {
	Data      string
	Timestamp int64
}

func Extract() {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Extract files (%s%s_*)", bnkRepo, bnkPrefix)
	color.Set(color.FgWhite)
	if _, err := os.Stat(bnkRepo); os.IsNotExist(err) {
		color.Set(color.FgRed)
		log.Printf("[x] Repositories is not exist (%s)", bnkRepo)
		color.Set(color.FgWhite)
		return
	}

	latest := time.Now()
	for {
		files, err := ioutil.ReadDir(bnkRepo)
		if err != nil {
			fmt.Println(err)
		}
		for _, f := range files {
			idx := strings.Index(f.Name(), bnkPrefix)
			if idx == 0 {
				//log.Printf("[-] File (%s %s)", f.Name(), f.ModTime())
				if f.ModTime().Sub(latest) >= 0 {
					fmt.Println(f.Name(), f.ModTime(), f.ModTime().Sub(latest))
					buf, _ := ioutil.ReadFile(bnkRepo + f.Name())
					hcPostReceipt(buf)
				}
			}
		}
		latest = time.Now()         // update
		time.Sleep(5 * time.Second) // 1 sec => 5 sec
	}
}

func hcPostReceipt(buf []byte) {
	b, _ := json.Marshal(JsonPost{Data: hex.EncodeToString(buf), Timestamp: time.Now().Unix()})
	resp, err := http.Post(httpHost+"/receipt/probe/"+uidNum, "application/json", bytes.NewBuffer(b))

	log.Printf("[p] http post %s/receipt/probe/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http post error: ", err)
		color.Set(color.FgWhite)
	} else {
		log.Printf("[-] Http response: %d", resp.StatusCode)
	}
}

func RunCOM(in io.ReadWriteCloser, out io.ReadWriteCloser, port1 string, port2 string) {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Run (%s => %s)", port1, port2)
	color.Set(color.FgWhite)
	for {
		buf := make([]byte, 32768)
		n, err := in.Read(buf)

		if err != nil {
			if err != io.EOF {
				color.Set(color.FgRed)
				log.Printf("[x] Reading from serial port: ", err)
				color.Set(color.FgWhite)
			}
		} else {
			buf = buf[:n]
			if n > 0 {
				log.Printf("[-] read %s  %d bytes, %s", port1, n, hex.EncodeToString(buf))
				nb, _ := out.Write(buf)
				log.Printf("[-] write %s %d bytes %s", port2, nb, hex.EncodeToString(buf))
				hcPostReceipt(buf)
			}
		}
		buf = nil
	}
}

func RunLPT(in *os.File, out *os.File, port1 string, port2 string) {
	color.Set(color.FgGreen)
	log.Printf("[v] thread Run (%s => %s)", port1, port2)
	color.Set(color.FgWhite)
	for {
		buf := make([]byte, 32768)
		n, err := in.Read(buf)

		if err != nil {
			if err != io.EOF {
				color.Set(color.FgRed)
				log.Printf("[x] Reading from serial port: ", err)
				color.Set(color.FgWhite)
			}
		} else {
			buf = buf[:n]
			if n > 0 {
				log.Printf("[-] read %s  %d bytes, %s", port1, n, hex.EncodeToString(buf))
				nb, _ := out.Write(buf)
				log.Printf("[-] write %s %d bytes %s", port2, nb, hex.EncodeToString(buf))
				hcPostReceipt(buf)
			}
		}
		buf = nil
	}
}

////////////////////////////////////////////////////////

func hcConfig() {
	ipAddr = GetOutboundIP().String()
	macAddr = GetOutboundMac(ipAddr)
	log.Println("----------------------------------------------------------------")
	if getConfig() == false {
		color.Set(color.FgRed)
		log.Printf("[x] Please, check your POS configuration.")
		color.Set(color.FgWhite)
		return
	}
	log.Println("----------------------------------------------------------------")
}

func hcOpenCOM(device string) io.ReadWriteCloser {

	baudrate, _ := strconv.Atoi(baudRate)
	intchtmo, _ := strconv.Atoi(intChTimeout)
	minreadsize, _ := strconv.Atoi(minReadSize)

	options := serial.OpenOptions{
		PortName:              device,
		BaudRate:              uint(baudrate),
		DataBits:              8,
		StopBits:              1,
		InterCharacterTimeout: uint(intchtmo),    //msec
		MinimumReadSize:       uint(minreadsize), //4
	}
	port, err := serial.Open(options)
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] %s serial.Open: %v", device, err)
		color.Set(color.FgWhite)
		return nil
	}
	return port
}

type License struct {
	Mac string
	Rcn string
	Ver string
}

func hcSignIn() {
	b, _ := json.Marshal(License{Mac: macAddr, Rcn: rcnNum, Ver: version})
	resp, err := http.Post(httpHost+"/pos/sign-in/", "application/json", bytes.NewBuffer(b))

	log.Printf("[p] http post %s/pos/sign-in/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http sign-in post error: ", err)
		color.Set(color.FgWhite)
	} else {
		s, _ := ioutil.ReadAll(resp.Body)
		log.Printf("[-] Http response: %d", resp.StatusCode)
		var result map[string]interface{}
		json.Unmarshal([]byte(s), &result)
		log.Printf("[-] code: %d", result["code"].(float64))
		if result["code"].(float64) != 200 {
			go func() {
				debug := true
				w := webview.New(debug)
				defer w.Destroy()
				w.SetTitle("Minimal webview example")
				w.SetSize(800, 600, webview.HintNone)
				w.Navigate(httpHost + "/pos/sign-up/" + macAddr)
				w.Run()
			}()
			return
		}
		license = result["license"].(string)
		log.Printf("[-] license: %s, version: %s", license, version)
	}
}

type JsonCheckIn struct {
	Name string
	Uid  string
	Rcn  string
	Mac  string
	Arch string
	Info string
}

func hcCheckIn() {
	b, _ := json.Marshal(JsonCheckIn{Name: deptName, Uid: uidNum, Rcn: rcnNum, Mac: macAddr, Arch: osArch, Info: osInfo})
	resp, err := http.Post(httpHost+"/check-in", "application/json", bytes.NewBuffer(b))

	log.Printf("[p] http post %s/check-in %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http check-on post error: ", err)
		color.Set(color.FgWhite)
	} else {
		log.Printf("[-] Http response: %d", resp.StatusCode)
	}
}

func doHeartBeat(t time.Time) {
	b, _ := json.Marshal(JsonCheckIn{Name: deptName, Uid: uidNum, Rcn: rcnNum, Mac: macAddr, Arch: osArch, Info: osInfo})
	resp, err := http.Post(httpHost+"/heartbeat/", "application/json", bytes.NewBuffer(b))
	//defer resp.Body.Close()

	log.Printf("[p] http post %s/heartbeat/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http heartbeat post error: ", err)
		color.Set(color.FgWhite)
	} else {

		log.Printf("[-] Http response: %d", resp.StatusCode)
	}

}

func hcHeartBeat() {
	hbtimer, _ := strconv.ParseInt(heartBeat, 10, 32)

	log.Printf("[v] module hcHeartBeat (per %d seconds)", hbtimer)
	go func() {
		ticker := time.NewTicker(time.Duration(hbtimer) * time.Second)
		defer ticker.Stop()

		//doHeartBeat(time.Now())
		for {
			select {
			case t := <-ticker.C:
				doHeartBeat(t)
			}
		}
	}()
}

func doPosHeartBeat(t time.Time) {
	b, _ := json.Marshal(License{Mac: macAddr, Rcn: rcnNum, Ver: version})
	resp, err := http.Post(httpHost+"/pos/heartbeat/", "application/json", bytes.NewBuffer(b))

	log.Printf("[p] http post %s/pos/heartbeat/ %s", httpHost, bytes.NewBuffer(b))
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Http heartbeat post error: ", err)
		color.Set(color.FgWhite)
	} else {

		log.Printf("[-] Http response: %d", resp.StatusCode)
	}

}

func hcPosHeartBeat() {
	hbtimer, _ := strconv.ParseInt(heartBeat, 10, 32)
	color.Set(color.FgGreen)
	log.Printf("[t] thread hcPosHeartBeat (per %d seconds)", hbtimer)
	color.Set(color.FgWhite)
	go func() {
		ticker := time.NewTicker(time.Duration(hbtimer) * time.Second)
		defer ticker.Stop()

		for {
			select {
			case t := <-ticker.C:
				doPosHeartBeat(t)
			}
		}
	}()
}

type WsData struct {
	License   string
	Command   string
	Message   string
	Timestamp int64
}

func hcConnWS() *websocket.Conn {
	for {
		u := url.URL{Scheme: "ws", Host: wsHost, Path: "/"}
		c, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
		if err != nil {
			log.Printf("[w] websocket dial error:", err)
			time.Sleep(1)
			continue
		}
		log.Printf("[w] connected to %s", u.String())
		wsConnected = 1
		b, _ := json.Marshal(WsData{License: license, Command: "Join", Message: "Hi", Timestamp: time.Now().Unix()})
		c.WriteMessage(websocket.TextMessage, b /*[]byte(b)*/)
		return c
	}
}

func hcWS() {
	color.Set(color.FgGreen)
	log.Printf("[t] thread hcWS %s", wsHost)
	color.Set(color.FgWhite)

	c := hcConnWS()
	defer c.Close()

	go func() {
		for {
			if wsConnected == 0 {
				time.Sleep(1)
				c = hcConnWS()
			}
			_, message, err := c.ReadMessage()
			if err != nil {
				color.Set(color.FgRed)
				log.Printf("[x] Http heartbeat post error: ", err)
				color.Set(color.FgWhite)
				wsConnected = 0
				continue
			}
			log.Printf("[w] received message: %s", message)

			var result map[string]interface{}
			json.Unmarshal([]byte(message), &result)
			if result["Command"].(string) == "Callback" {
				go func() {
					debug := true
					w := webview.New(debug)
					defer w.Destroy()
					w.SetTitle("Hancom: WS")
					w.SetSize(800, 600, webview.HintNone)
					w.Navigate(result["Message"].(string))
					w.Run()
				}()
			}
		}
	}()
}

type hcWriter struct {
	io.Writer
}

func (m *hcWriter) Write(p []byte) (n int, err error) {
	n, err = m.Writer.Write(p)

	if flusher, ok := m.Writer.(interface{ Flush() }); ok {
		flusher.Flush()
	} else if syncer := m.Writer.(interface{ Sync() error }); ok {
		// Preserve original error
		if err2 := syncer.Sync(); err2 != nil && err == nil {
			err = err2
		}
	}
	return
}

////////////////////////////////////////////////////////

func GetOutboundIP() net.IP {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] net.Dial error: %s", err)
		color.Set(color.FgWhite)
	}
	defer conn.Close()
	return conn.LocalAddr().(*net.UDPAddr).IP
}

func GetOutboundMac(currentIP string) string {
	var currentNetworkHardwareName string
	interfaces, _ := net.Interfaces()
	for _, interf := range interfaces {
		if addrs, err := interf.Addrs(); err == nil {
			for _, addr := range addrs {
				if strings.Contains(addr.String(), currentIP) {
					currentNetworkHardwareName = interf.Name
				}
			}
		}
	}
	netInterface, err := net.InterfaceByName(currentNetworkHardwareName)
	if err != nil {
		color.Set(color.FgRed)
		log.Printf("[x] Interface error: %s", err)
		color.Set(color.FgWhite)
	}
	return netInterface.HardwareAddr.String()
}

var httpHost string
var wsHost string
var servName string
var deptName string
var uidNum string
var rcnNum string
var macAddr string
var ipAddr string
var baudRate string
var Printer string
var Port1 string
var Port2 string
var Token string
var heartBeat string
var intChTimeout string
var minReadSize string
var posType string
var bnkRepo string
var bnkPrefix string
var osArch string
var osInfo string
var envInfo string
var wsConnected int = 0
var license string = "1234"
var version string = ""
var build string = ""

func getConfig() bool {
	err := godotenv.Load("c:\\hc\\.env")
	if err != nil {
		log.Printf("Error loading C:\\hc\\.env file")
		return false
	}
	//httpHost = "https://smart.hancomlifecare.com"
	httpHost = os.Getenv("SERVER")
	if httpHost == "" {
		color.Set(color.FgRed)
		log.Printf("[x] Environment(.env) SERVER read error")
		color.Set(color.FgWhite)
		httpHost = "https://smart.hancomlifecare.com"
	}
	wsHost = os.Getenv("WS")
	servName = os.Getenv("SERVICE")
	deptName = os.Getenv("NAME")
	uidNum = os.Getenv("UID")
	rcnNum = os.Getenv("RCN")
	baudRate = os.Getenv("BAUDRATE")
	if baudRate == "" {
		baudRate = "19200"
	}
	Printer = os.Getenv("PRINTER")
	Port1 = os.Getenv("PORT1")
	Port2 = os.Getenv("PORT2")
	heartBeat = os.Getenv("HEARTBEAT")
	intChTimeout = os.Getenv("INTERCHTMO")
	if intChTimeout == "" {
		intChTimeout = "50"
	}
	minReadSize = os.Getenv("MINREADSIZE")
	if minReadSize == "" {
		minReadSize = "0"
	}
	posType = os.Getenv("POSTYPE")
	if posType == "" {
		posType = "COM"
	}
	bnkRepo = os.Getenv("BNK_REPO")
	bnkPrefix = os.Getenv("BNK_PREFIX")
	ipAddr = GetOutboundIP().String()
	macAddr = GetOutboundMac(ipAddr)

	log.Printf("[*] Host                     : %s", httpHost)
	if wsHost != "" {
		log.Printf("[*] WS                       : %s", wsHost)
	}
	if servName != "" {
		log.Printf("[*] Service                  : %s", servName)
	}
	if deptName != "" {
		log.Printf("[*] Name                     : %s", deptName)
	}
	if uidNum != "" {
		log.Printf("[*] Uid                      : %s", uidNum)
	}
	log.Printf("[*] Rcn                      : %s", rcnNum)
	log.Printf("[*] BaudRate                 : %s", baudRate)
	log.Printf("[*] Printer                  : %s", Printer)
	log.Printf("[*] Port1                    : %s", Port1)
	log.Printf("[*] Port2 (POS)              : %s", Port2)
	log.Printf("[*] HeartBeat                : %s", heartBeat)
	log.Printf("[*] Inter Character Timeout  : %s", intChTimeout)
	log.Printf("[*] Minimum Read Size        : %s", minReadSize)
	log.Printf("[*] POS Type                 : %s", posType)
	if strings.ToUpper(posType) == "BNK" {
		log.Printf("[*] BNK Repo                 : %s", bnkRepo)
		log.Printf("[*] BNK Prefix               : %s", bnkPrefix)
	}
	log.Printf("[*] IP address               : %s", ipAddr)
	log.Printf("[*] Mac address              : %s", macAddr)
	if strings.ToUpper(posType) != "BNK" {
		log.Println("----------------------------------------------------------------")
		log.Printf("[v] POS: vPort %s (thuru %s) <=> Printer (%s)", Port2, Port1, Printer)
	}
	envInfo = string(httpHost + "/" + deptName + "/" + uidNum + "/" + rcnNum + "/" + baudRate + "/" + Printer + "/" + Port1 + "/" + Port2 + "/" + heartBeat + "/" + intChTimeout + "/" + minReadSize + "/" + posType + "/" + bnkRepo + "/" + bnkPrefix)

	/*
		debug := true
		w := webview.New(debug)
		defer func() {
			w.Destroy()
		}()
		w.SetTitle("Minimal webview example")
		w.SetSize(800, 600, webview.HintNone)
		w.Navigate("https://en.m.wikipedia.org/wiki/Main_Page")
		w.Run()
	*/
	return true
}
