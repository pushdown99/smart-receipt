package main

import (
	"fmt"
	"syscall"
)

func main() {
	fmt.Println("Hello World!")

	InpOutDll, err := syscall.LoadLibrary("C:\\hc\\inpout32.dll")
	if err != nil {
		fmt.Println("Error Loading inpout32 dll, ", err)
	}
	defer func() {
		syscall.FreeLibrary(InpOutDll)
	}()

	PAddressOut32, err := syscall.GetProcAddress(syscall.Handle(InpOutDll), "Out32")
	if err != nil {
		fmt.Println("Error getting ProcAdress Out32, ", err)
	}
	PAddressInp32, err := syscall.GetProcAddress(syscall.Handle(InpOutDll), "Inp32")
	if err != nil {
		fmt.Println("Error getting ProcAdress Inp32, ", err)
	}
	//Returns TRUE if the InpOut driver was opened successfully
	IsInpOutDriverOpen, err := syscall.GetProcAddress(syscall.Handle(InpOutDll), "IsInpOutDriverOpen")
	if err != nil {
		fmt.Println("Error getting ProcAdress IsInpOutDriverOpen, ", err)
	}

	IsOpen, _, callErr := syscall.Syscall(uintptr(IsInpOutDriverOpen), 0, 0, 0, 0)
	if callErr != 0 {
		fmt.Println("Error in ProcAdress IsInpOutDriverOpen! ", callErr)
	}

	if uint16(IsOpen) == 1 {
		_, _, callErr := syscall.Syscall(uintptr(PAddressOut32),
			1,
			uintptr(890),
			uintptr(0),
			0)
		if callErr != 0 {
			fmt.Println("Error in LTP Write! ", callErr)
		}
		Word, _, callErr := syscall.Syscall(uintptr(PAddressInp32),
			0,
			uintptr(890),
			0,
			0)
		if callErr != 0 {
			fmt.Println("Error in LTP Read! ", callErr)
		} else {
			fmt.Println("Data in is ", Word)

		}
	} else {
		fmt.Println("InpOut driver wasn't opened successfully!")
	}
}
