package main

import (
	"encoding/hex"
	"io"
	"log"
	"os"
	"strconv"

	"github.com/jacobsa/go-serial/serial"
	"github.com/joho/godotenv"
)

func hcOpen(device string, baudrate int) io.ReadWriteCloser {
	options := serial.OpenOptions{
		PortName:        device,
		BaudRate:        uint(baudrate),
		DataBits:        8,
		StopBits:        1,
		MinimumReadSize: 4,
	}
	port, err := serial.Open(options)
	if err != nil {
		log.Printf("[e] serial.Open: %v", err)
		return nil
	}
	return port
}

var httpHost string
var deptName string
var uidNum string
var rcnNum string
var baudRate string
var Printer string
var Port1 string
var Port2 string
var Token string

func getConfig() bool {
	err := godotenv.Load("c:\\hc\\.env")
	if err != nil {
		log.Fatal("Error loading .env file")
		return false
	}
	httpHost = os.Getenv("SERVER")
	deptName = os.Getenv("NAME")
	uidNum = os.Getenv("UID")
	rcnNum = os.Getenv("RCN")
	baudRate = os.Getenv("BAUDRATE")
	Printer = os.Getenv("PRINTER")
	Port1 = os.Getenv("PORT1")
	Port2 = os.Getenv("PORT2")

	log.Printf("[*] Host       : %s", httpHost)
	log.Printf("[*] Name       : %s", deptName)
	log.Printf("[*] Uid        : %s", uidNum)
	log.Printf("[*] Rcn        : %s", rcnNum)
	log.Printf("[*] BaudRate   : %s", baudRate)
	log.Printf("[*] Printer    : %s", Printer)
	log.Printf("[*] Port1      : %s", Port1)
	log.Printf("[*] Port2 (POS): %s", Port2)

	return true
}

func hcConfig() {
	if getConfig() == false {
		log.Printf("[e] Please, check your POS configuration.")
		return
	}
}

func main() {
	log.Println("POS agent Run!")
	log.Println("------------------------------------------------------")
	hcConfig()
	log.Println("------------------------------------------------------")

	baudrate, _ := strconv.Atoi(baudRate)
	buf1, _ := hex.DecodeString("20200d0a1b61011b2121c8a3b3b2b9aeb0ed1b21000d0a1b6100200d0ac0fcc1d6bdc320bfcfbbeab1b820bcadbdc5b7ce2035302028bcadbdc5b5bf290d0a3430322d39312d3431363232202020202054656c2e202020303633293235332d393430300d0a")
	buf2, _ := hex.DecodeString("2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a2a2ab5b5bcadb1b3c8af20b9d720c8afbad2bdc320b9ddb5e5bdc320bfb5bcf6c1f5c1f6c2fc21210d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a312e20c7aeb2c928b3aac5c2c1d6b4ebc7a5bdc3bcb1c1fd29202020202020202020202020202020200d0a2a3937393131353732383433363839392020202020392c303030202020312020202020392c3030300d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0ac3d1bcf6b7ae202020202020202020202020202020202020202020202020202020202020202020310d0ac7d5b0e8bed72020202020202020202020202020202020202020202020202020202020392c3030300d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a1b2100c4abb5e5c0d42020202020202020202020202020202020202020202020202020202020392c3030300d0a1b21002d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0ac7f6c0dcbed7202020202020202020202020202020202020202020202020202020202020202020300d0a1b21002d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a1b21000d0ab8e9bcbcbbf3c7b0b0a1bed72020202020202020202020202020202020202020202020392c3030301b21000d0ab0fabcbcbbf3c7b0b0a1bed7202020202020202020202020202020202020202020202020202020301b21000d0abace202020b0a1202020bcbc202020202020202020202020202020202020202020202020202020301b21000d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0ac8b8bff8bcbab8ed3a20b1e8bab9bcf820202020c8b8bff8b9f8c8a33a20303033303335363220200d0ac0ccc0fcc0fbb8b33a2020202020202020353220c0fbb8b3c0dcbed73a20202020202035320d0a0d0ab8c5c3e2c3b33ab1e8bab9bcf8202020202020202020202020202020202020202020202020200d0ac6c7b8c5c0cfc0da3a323032312d30362d33302020c6c7b8c5bdc3b0a33a31343a313520202020200d0ab8deb8f03a20b9ccc8ad2020202020202020202020202020202020202020202020202020202020200d0ac6c7b8c5c0da3ab9dab9ccc8ad2020202020202020202020202020202020202020202020202020200d0a1b61011b2121c0fcc7a5b9f8c8a33a32323130363330303335201b21000d0a1b61001b33001d68461d77021b61011d6b0432323130363330303335000d0a1d21001b6100")
	buf3, _ := hex.DecodeString("2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2020202020202020200d0a2a2a2033b8b8bff8c0ccbbf320b9e8b4de20c7d820b5e5b8b3b4cfb4d92e202020202020202020200d0a200d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a1b2121bdc5bfebc4abb5e5bdc2c0ce1b210028b0edb0b4bfeb290d0ab1b820b8c520c0da3a20b1e8bab9bcf820202020202020202020202020200d0ac4abb5e5b9f8c8a33a202d2a2a2d2a2a2a2a2d2a2a2a2a0d0ab7d4b5a5c4abb5e5bbe7202020202020202020200d0ab0a1b8cdc1a14e4f3a200d0a1b2121bdc2c0cec0cfbdc33a20323130363330313431350d0ab0c5b7a1b1ddbed73a201b2121392c3030301b21000d0ac7d2baceb0b3bff93a30b0b3bff9202020202020c0afc8bfb1e2b0a33a2a2a2f2a2a0d0abdc2c0ceb9f8c8a33a2035353033313137361b21000d0a2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a1b33001d68461d77021b61011d6b043535303331313736000d0a1d21101d21001b61002d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d2d0d0a200d0a")
	buf4, _ := hex.DecodeString("0d0a0d0a0d0a1b6d")
	out := hcOpen(Port2, baudrate)
	if out == nil {
		return
	}
	out.Write(buf1)
	out.Write(buf2)
	out.Write(buf3)
	out.Write(buf4)

}
